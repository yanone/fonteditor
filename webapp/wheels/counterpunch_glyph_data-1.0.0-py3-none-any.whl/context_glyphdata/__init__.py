"""
Context Glyph Data.

Offline Unicode glyph data and camelCase glyph-name generation.
"""

from .core import glyph_data_for_unicode as glyph_name_for_unicode
from .plugin import (
    glyph_data_for_name,
    glyph_data_for_unicode,
    glyph_name_to_unicode,
    lookup,
)

__version__ = "1.0.0"
__all__ = [
    "glyph_data_for_unicode",
    "glyph_name_for_unicode",
    "glyph_name_to_unicode",
    "glyph_data_for_name",
    "lookup",
]
