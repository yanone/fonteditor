"""Offline access to the Unicode data embedded in this distribution."""

from __future__ import annotations

import gzip
import json
from functools import lru_cache
from importlib.resources import files
from typing import Any, Dict, Optional, Union


@lru_cache(maxsize=1)
def _artifact() -> Dict[str, Any]:
    resource = files("context_glyphdata").joinpath("data/ucd.json.gz")
    with gzip.open(resource, "rt", encoding="utf-8") as stream:
        return json.load(stream)


@lru_cache(maxsize=1)
def _records() -> Dict[int, Dict[str, Any]]:
    artifact = _artifact()
    fields = artifact["fields"]
    return {record[0]: dict(zip(fields, record)) for record in artifact["records"]}


def metadata() -> Dict[str, Any]:
    """Return a copy of the Unicode artifact metadata."""
    return dict(_artifact()["metadata"])


def ucd_data(codepoint: int) -> Optional[Dict[str, Any]]:
    """Return legacy UCD-style data needed by the glyph-name transform."""
    record = _records().get(codepoint)
    if record is None:
        return None
    if not record["name"] or record["name"].startswith("<"):
        return None
    return {"Name": record["name"]}


def record_for_unicode(codepoint: int) -> Optional[Dict[str, Any]]:
    """Return complete embedded Unicode data for a codepoint."""
    record = _records().get(codepoint)
    return dict(record) if record else None


def named_codepoints():
    """Yield codepoints with stable Unicode names without copying records."""
    for codepoint, record in _records().items():
        if record["name"] and not record["name"].startswith("<"):
            yield codepoint


def unicode_from_value(value: Union[int, str]) -> Optional[int]:
    """Parse a codepoint, U+ notation, or a single Unicode character."""
    if isinstance(value, int):
        return value if 0 <= value <= 0x10FFFF else None
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    if normalized.upper().startswith("U+"):
        try:
            return int(normalized[2:], 16)
        except ValueError:
            return None
    if len(normalized) == 1:
        return ord(normalized)
    return None
