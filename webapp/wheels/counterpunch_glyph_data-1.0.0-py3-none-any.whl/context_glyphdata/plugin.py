"""Counterpunch plugin entry point and public glyph-data lookup API."""

from __future__ import annotations

from functools import lru_cache
from typing import Any, Dict, Optional, Union

from .core import glyph_data_for_unicode as glyph_name_for_unicode
from .data import metadata, named_codepoints, record_for_unicode, unicode_from_value


@lru_cache(maxsize=1)
def _glyph_names() -> Dict[str, int]:
    names = {}
    for codepoint in named_codepoints():
        names.setdefault(glyph_name_for_unicode(codepoint), codepoint)
    return names


def glyph_name_to_unicode(name: str) -> Optional[int]:
    """Return the codepoint for a generated glyph name, if it is known."""
    return _glyph_names().get(name)


def _with_glyph_name(record: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if record is not None:
        record["glyph_name"] = glyph_name_for_unicode(record["codepoint"])
    return record


def glyph_data_for_unicode(value: Union[int, str]) -> Optional[Dict[str, Any]]:
    """Return complete embedded glyph data for a Unicode scalar."""
    return _with_glyph_name(record_for_unicode(unicode_from_value(value)))


def glyph_data_for_name(name: str) -> Optional[Dict[str, Any]]:
    """Return a complete Unicode record for a generated glyph name."""
    codepoint = glyph_name_to_unicode(name)
    return _with_glyph_name(record_for_unicode(codepoint))


def lookup(value: Union[int, str]) -> Optional[Dict[str, Any]]:
    """Look up complete glyph data by codepoint, U+ notation, character, or glyph name."""
    codepoint = unicode_from_value(value)
    if codepoint is None and isinstance(value, str):
        codepoint = glyph_name_to_unicode(value)
    return _with_glyph_name(record_for_unicode(codepoint))


@lru_cache(maxsize=1)
def search_records() -> tuple[Dict[str, Any], ...]:
    """Return flattened named records for host-side search indexing."""
    return tuple(
        glyph_data_for_unicode(codepoint)
        for codepoint in named_codepoints()
        if glyph_data_for_unicode(codepoint) is not None
    )


class GlyphDataPlugin:
    """Counterpunch's offline Unicode glyph-data provider."""

    glyph_name_to_unicode = staticmethod(glyph_name_to_unicode)
    glyph_data_for_unicode = staticmethod(glyph_data_for_unicode)
    glyph_data_for_name = staticmethod(glyph_data_for_name)
    lookup = staticmethod(lookup)
    search_records = staticmethod(search_records)
    metadata = staticmethod(metadata)


def plugin() -> GlyphDataPlugin:
    """Load the provider advertised by ``counterpunch_glyph_data_plugins``."""
    return GlyphDataPlugin()
